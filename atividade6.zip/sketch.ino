#include <ESP32Servo.h>

// Definição dos pinos conforme o novo diagrama
#define TRIG_PIN 14   // Pino Trig do ultrassônico no D14[cite: 4]
#define ECHO_PIN 12   // Pino Echo do ultrassônico no D12[cite: 4]
#define SERVO_PIN 22  // Pino de sinal do Micro-servo no D22[cite: 4]
#define LED_PIN 16    // Pino de controle do LED no D16[cite: 4]

Servo meuservo;

void setup() {
  Serial.begin(9600);
  
  // Configuração dos pinos
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  pinMode(LED_PIN, OUTPUT);
  
  // Inicialização do Micro-servo e estado inicial dos atuadores
  meuservo.attach(SERVO_PIN);
  meuservo.write(0);      // Cancela fechada
  digitalWrite(LED_PIN, LOW); // LED apagado
}

void loop() {
  long duration, distance;

  // Emitir um pulso ultrassônico
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  // Medir o tempo de retorno do eco
  duration = pulseIn(ECHO_PIN, HIGH);

  // Calcular a distância em centímetros
  distance = (duration / 2) * 0.0343;

  // Exibir a distância no monitor serial
  Serial.print("Distancia: ");
  Serial.print(distance);
  Serial.println(" cm");

  // Lógica do estacionamento: carro próximo (< 100 cm)
  if (distance < 100) {
    digitalWrite(LED_PIN, HIGH); // Acende o LED
    meuservo.write(90);          // Abre a cancela (90 graus)
  } else {
    digitalWrite(LED_PIN, LOW);  // Apaga o LED
    meuservo.write(0);           // Fecha a cancela (0 graus)
  }

  delay(500); // Pausa para estabilizar a leitura
}